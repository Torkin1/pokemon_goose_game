package it.walle.pokemongoosegame;

import android.content.Context;
import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;

import com.android.volley.Response;

import org.junit.Test;

import it.walle.pokemongoosegame.database.pokeapi.DAOType;
import it.walle.pokemongoosegame.entity.pokeapi.Name;
import it.walle.pokemongoosegame.entity.pokeapi.type.Type;
import it.walle.pokemongoosegame.entity.pokeapi.EntityPointer;

public class DAOTypeTest {

    private static final String TAG = "DAOTypeTest";

    @Test
    public void LoadTypeByNameTest(){
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DAOType dao = DAOType.getReference(context);
        Response.Listener<Type> listener = new Response.Listener<Type>() {
            @Override
            public void onResponse(Type response) {
                Log.d(TAG, "onResponse");
                Log.d(TAG, "name=" + response.getName());
                Log.d(TAG, "id=" + response.getId());
                for (Name n : response.getNames()){
                    Log.d(TAG, "LocalizedName=" + n.getName());
                    Log.d(TAG, "language=" + n.getLanguage().getName());
                }
                for (EntityPointer p : response.getDamage_relations().getDouble_damage_from()){
                    Log.d(TAG, "double_damage_from=" + p.getName());
                }
                for (EntityPointer p : response.getDamage_relations().getDouble_damage_to()){
                    Log.d(TAG, "double_damage_to=" + p.getName());
                }
                for (EntityPointer p : response.getDamage_relations().getHalf_damage_from()){
                    Log.d(TAG, "halfDamageFrom=" + p.getName());
                }
                for (EntityPointer p : response.getDamage_relations().getHalf_damage_to()){
                    Log.d(TAG, "halfDamageTo=" + p.getName());
                }
                for (EntityPointer p : response.getDamage_relations().getNo_damage_from()){
                    Log.d(TAG, "noDamageFrom=" + p.getName());
                }
                for (EntityPointer p : response.getDamage_relations().getNo_damage_to()){
                    Log.d(TAG, "noDamageTo=" + p.getName());
                }
            }
        };
        dao.LoadTypeByName("water", listener, null);
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            Log.w(TAG, e.getMessage(), e);
        }

    }
}
