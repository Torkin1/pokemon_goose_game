package it.walle.pokemongoosegame.game;

public enum PlayerParamGroup {
    PLAYER,
    POKEMON,
}
