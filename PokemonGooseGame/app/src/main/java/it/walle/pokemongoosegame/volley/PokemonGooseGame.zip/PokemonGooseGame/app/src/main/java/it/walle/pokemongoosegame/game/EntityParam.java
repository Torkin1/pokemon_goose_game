package it.walle.pokemongoosegame.game;

public interface EntityParam {
}
