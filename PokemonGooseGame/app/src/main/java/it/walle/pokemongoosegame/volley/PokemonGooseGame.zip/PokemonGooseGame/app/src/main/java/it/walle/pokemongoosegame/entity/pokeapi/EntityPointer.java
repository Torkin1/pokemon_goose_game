package it.walle.pokemongoosegame.entity.pokeapi;

public class EntityPointer {
    private String name;        // Name of the entity
    private String url;         // url api for the entity

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
