package it.walle.pokemongoosegame;

import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import it.walle.pokemongoosegame.boardfactory.BlueCellSettings;
import it.walle.pokemongoosegame.boardfactory.BoardFactory;
import it.walle.pokemongoosegame.boardfactory.procedurallygenerated.CreateBoardPGBean;
import it.walle.pokemongoosegame.entity.board.Board;
import it.walle.pokemongoosegame.entity.board.cell.Cell;
import it.walle.pokemongoosegame.entity.board.pgsettings.BoardPGParams;
import it.walle.pokemongoosegame.entity.board.pgsettings.BoardPGSettings;
import it.walle.pokemongoosegame.entity.board.pgsettings.WhatYellowCellStartingIndex;
import it.walle.pokemongoosegame.entity.board.pgsettings.WhatYellowEffectName;

public class BoardFactoryPGTest {

    private final String TAG = this.getClass().getName();
    private final String boardSettingsName = "testBoardSettings";

    @Test
    public void createBoardTest(){

        try {
            BoardPGSettings settings = new BoardPGSettings();

            // Sets up a list of n YellowEffectName items
            final int n = 5;
            List<WhatYellowEffectName> yellowEffectNames = new ArrayList<>();
            for (int i = 0; i < n; i ++){
                WhatYellowEffectName yellowEffectName = new WhatYellowEffectName();
                yellowEffectName.setBoardSettingsName(boardSettingsName);
                yellowEffectName.setYellowEffectClassName("YellowEffectClassName" + i);
                yellowEffectNames.add(yellowEffectName);
            }
            settings.setYellowEffectNames(yellowEffectNames);

            // Sets up a list of BlueCellSettings items. Blue cells will be placed every n cells
            List<BlueCellSettings> blueCellSettingsList = new ArrayList<>();
            for (int i = 0; i < n; i ++){
                BlueCellSettings blueCellSettings = new BlueCellSettings();
                blueCellSettings.setBoardSettingsName(boardSettingsName);
                blueCellSettings.setBlueCellName("BlueCellClassName" + i);
                blueCellSettings.setBoardIndex(i * n);
                blueCellSettingsList.add(blueCellSettings);
            }
            settings.setBlueCellSettings(blueCellSettingsList);

            // Starting indices of yellow cells are 5 and 9
            List<WhatYellowCellStartingIndex> whatYellowCellStartingIndices = new ArrayList<>();
            for (int i = 5; i <= 9; i += 4){
                WhatYellowCellStartingIndex whatYellowCellStartingIndex = new WhatYellowCellStartingIndex();
                whatYellowCellStartingIndex.setIndex(i);
                whatYellowCellStartingIndices.add(whatYellowCellStartingIndex);
            }
            settings.setYellowCellStartingIndexes(whatYellowCellStartingIndices);

            // Board of 64 cells with a yellow cell every 9 cells
            BoardPGParams boardPGParams = new BoardPGParams();
            boardPGParams.setNumCells(64);
            boardPGParams.setYellowCellDelta(9);
            settings.setBoardPGParams(boardPGParams);

            // Setting up a CreateBoard bean to feed the board factory
            CreateBoardPGBean bean = new CreateBoardPGBean();
            bean.setBoardSettings(settings);
            BoardFactory.getInstance(InstrumentationRegistry.getInstrumentation().getTargetContext(), bean).createBoard();

            // Logs all infos about the newly created board
            Board board = bean.getBoard();
            for (Cell c : board.getCells()){
                Log.i(TAG, "position=" + board.getCells().indexOf(c) + " type=" + c.getClass().getSimpleName());
            }
        } catch (ClassNotFoundException e) {
            Log.e(TAG, e.getMessage(), e);
        }

    }
}
