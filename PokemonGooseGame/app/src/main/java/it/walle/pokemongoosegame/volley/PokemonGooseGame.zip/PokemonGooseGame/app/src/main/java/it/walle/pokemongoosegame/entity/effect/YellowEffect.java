package it.walle.pokemongoosegame.entity.effect;

public abstract class YellowEffect extends Effect{
}
