package it.walle.pokemongoosegame.entity.pokeapi.allpokemon;

public class CountPokemon {
    private int count; //Numero di pokemon

    public CountPokemon() {}

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
